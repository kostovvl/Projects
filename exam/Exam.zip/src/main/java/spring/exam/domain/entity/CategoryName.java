package spring.exam.domain.entity;

public enum CategoryName {

    Food, Drink, Household, Other

}
